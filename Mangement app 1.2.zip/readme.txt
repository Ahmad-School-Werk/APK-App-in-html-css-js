
FREE APP

Created by WebIntoApp.com on Tuesday 26th of December 2023 10:58:17 PM.

Release APK & App Bundle (AAB) ready to be submitted to Google Play Store 
and to any other APK / AAB store over the internet.

-------------------------------------
App ID:			216784
App Key:		ZzROVzSJcDgpUVUzCCCVseOzdCdAFXhC
App Name:		Mangement app
App Version:	1.2
Package:		com.cobbe.mangementapp
Mode:			Free App
-------------------------------------

Your free app is ready, you can now publish it to the 
google play store and to any apk app store on the internet.

-------------------------------------
Please note, your app is under a FREE mode, you can always 
convert it to your own dedicated and branded mobile app for 
Android and iOS with all the premium features at:

https://www.webintoapp.com/author/apps/216784/edit?cmd=app-switcher

-------------------------------------
Here are some useful links:
-------------------------------------

You can edit your app at:
https://www.webintoapp.com/author/apps

Get installs statistics at:
https://www.webintoapp.com/author/stats?appid=216784

The Author Area:
https://www.webintoapp.com/author/dashboard

-------------------------------------
WebIntoApp.com Team.
https://www.webintoapp.com
-------------------------------------
